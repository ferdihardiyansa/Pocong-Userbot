from time import sleep
from userbot import CMD_HELP
from userbot.events import register


@register(outgoing=True, pattern=r'^\.kill(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("`Mau Gue Santet Lu Broo?..`")
    sleep(4)
    await typew.edit("0%")
    number = 1
    await typew.edit(str(number) + "%   ▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████████▌")
    sleep(1)
    await typew.edit("Tapi Boong......:v")
    # I did it for two hours :D just ctrl+c - crtl+v


CMD_HELP.update({
    'fakeload':
    '.kill\
        \nUsage: Gagal Santet.'
})
