#Module Punya Si @Pocongonlen
#https://github.com/poocong/Pocong-Userbot
#
#Mau Maling Kah? 
#Silahkan Maling Aja Xixixi
#Gak Usah Sungkan

from time import sleep
from userbot import CMD_HELP, bot
from userbot.events import register
from telethon import events
import asyncio

#Sengaja Bikin Banyak Banyak Credit Nya
#P o c o n g - U s e r b o t
#Tapi Kalo Mau Maling Mah Silakan
#Enjoy

@register(outgoing=True, pattern='^.hai(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1)
    await typew.edit("**Hai ,  Assalamualaikum**")
    sleep(1)
    await typew.edit("Kalian Nungguin aku gak??")
    sleep(1)
    await typew.edit("Ih ga mau🤢")
    sleep(1)
    await typew.edit("gasukaa😫")
    sleep(1)
    await typew.edit("__GELAYY__🤮")
    
   
@register(outgoing=True, pattern='^.kntl(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1)
    await typew.edit("Tau kh kalian wahai tuan-tuan??")
    sleep(1)
    await typew.edit("se**KONT0L** **K0NTOL** nya si **K0NTOL**")
    sleep(1)
    await typew.edit("lebih **KONTOL** lagi")              
    sleep(1)
    await typew.edit("kalian")
    await typew.edit("kalian **K**")
    await typew.edit("kalian **Ko**")
    await typew.edit("kalian **Kon**")
    await typew.edit("kalian **Kont**")
    await typew.edit("kalian **Konto**")
    await typew.edit("kalian **Kontol**")


@register(outgoing=True, pattern='^.alay(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1)
    await typew.edit("eh kamu, iya kamu")
    sleep(1)
    await typew.edit("**ALAY** bnget sih")
    sleep(1)
    await typew.edit("spam bot mulu")
    sleep(1)
    await typew.edit("baru jadi userbot ya?? xixixi")
    sleep(1)
    await typew.edit("pantes **NORAK**")

    
@register(outgoing=True, pattern='^.jawa(?: |$)(.*)') 
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1)
    await typew.edit("baik")
    sleep(1)
    await typew.edit("Tidak Sombong")
    sleep(1)
    await typew.edit("Ganteng")
    sleep(1)
    await typew.edit("Sopan")
    sleep(1)
    await typew.edit("Rajin")
    sleep(1)
    await typew.edit("Budiman")
    sleep(1)
    await typew.edit("Alim")
    sleep(1)
    await typew.edit("Berguna")
    sleep(1)
    await typew.edit("**Nguli Juga**")
    sleep(1)
    await typew.edit("Pemaaf")
    sleep(1)
    await typew.edit("Jujur")
    sleep(1)
    await typew.edit("Tidk Sombong")
    sleep(1)
    await typew.edit("Kaya")
    sleep(1)
    await typew.edit("Pokoknya Jawa Pro Dah")
    sleep(1)
    await typew.edit("Tidak Seperti Yang Lain")
    sleep(1)
    await typew.edit("Bersama Kuli Membangun Negri")
    sleep(1)
    await typew.edit("eh salah salah, \nBersama **Jawa** Membangun Negri")
    
@register(outgoing=True, pattern='^.erpe(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1)
    await typew.edit("Hai, Kamu Anak Erpe Ya")
    sleep(1)
    await typew.edit("Kok Pake Muka Orang sih?")
    sleep(1)
    await typew.edit("Oh iya, Muka Anak Erpe Kan")
    sleep(1)
    await typew.edit("**BURIK - BURIK**")
    sleep(1)
    await typew.edit("Jadinya Pake Muka Orang")
    sleep(1)
    await typew.edit("Karena Muka Anak erpe")
    sleep(1)
    await typew.edit("**BURIK - BURIK**")
    sleep(1)
    await typew.edit("Canda **BURIK**")
    sleep(1)
    await typew.edit("Lari Ada Plastik KePanasan")
    
    
@register(outgoing=True, pattern='^.lopu(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1)
    await typew.edit("`Cuma Mau Bilang`")
    sleep(1)
    await typew.edit("`A`")
    await typew.edit("`Ak`")
    await typew.edit("`Aku`")
    await typew.edit("`Aku S`")
    await typew.edit("`Aku Sa`")
    await typew.edit("`Aku Say`")
    await typew.edit("`Aku Saya`")
    await typew.edit("`Aku Sayan`")
    await typew.edit("`Aku Sayang`")
    await typew.edit("`Aku Sayang K`")
    await typew.edit("`Aku Sayang Ka`")
    await typew.edit("`Aku Sayang Kam`")
    await typew.edit("`Aku Sayang Kamu`")
    sleep(1)
    await typew.edit("`I LOVE YOU 💞`")
    
@register(outgoing=True, pattern='^.hujan(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("`H`")
    await typew.edit("`Hm`")
    await typew.edit("`Hmm`")
    await typew.edit("`Hmmm`")
    await typew.edit("`Hmmmm`")
    await typew.edit("`Hmmmmm`")
    sleep(2)
    await typew.edit("`Hujan Hujan Gini Ange😔`")
    sleep(2)
    await typew.edit("`Enaknya Coli🤤`")
    sleep(1)
    await typew.edit("`8✊===D`")
    await typew.edit("`8=✊==D`")
    await typew.edit("`8==✊=D`")
    await typew.edit("`8===✊D`")
    await typew.edit("`8==✊=D`")
    await typew.edit("`8=✊==D`")
    await typew.edit("`8✊===D`")
    await typew.edit("`8=✊==D`")
    await typew.edit("`8==✊=D`")
    await typew.edit("`8===✊D`")
    await typew.edit("`8==✊=D`")
    await typew.edit("`8=✊==D`")
    await typew.edit("`8✊===D`")
    sleep(2)
    await typew.edit("`Ahhh🤤`")
    sleep(1)
    await typew.edit("`8✊===D`")
    await typew.edit("`8=✊==D`")
    await typew.edit("`8==✊=D`")
    await typew.edit("`8===✊D`")
    await typew.edit("`8==✊=D`")
    await typew.edit("`8=✊==D`")
    await typew.edit("`8✊===D`")
    await typew.edit("`8=✊==D`")
    await typew.edit("`8==✊=D`")
    await typew.edit("`8===✊D`")
    await typew.edit("`8==✊=D`")
    await typew.edit("`8=✊==D`")
    await typew.edit("`8✊===D`")
    await typew.edit("`crotss💦`")
    await typew.edit("`crotss💦💦`")
    await typew.edit("`crotss💦💦💦🤤`")
    sleep(2)
    await typew.edit("`H`")
    await typew.edit("`Hm`")
    await typew.edit("`Hmm`")
    await typew.edit("`Hmmm😔`")
    sleep(2)
    await typew.edit("`Ini Untuk Yang Terkahir`")
    sleep(2)
    await typew.edit("`Kenapa Ya Gw Coli Tadi😔`")
    sleep(2)
    await typew.edit("`Dah la besok besok ga mau lagi`")
    
@register(outgoing=True, pattern='^.ange(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("`Ayanggggg😖`")
    sleep(1)
    await typew.edit("`Ange😫`")
    sleep(1)
    await typew.edit("`Ayukkk Ewean Ayanggg🤤`")

@register(outgoing=True, pattern='^.engas(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("Udah nggak kuat nahan")
    sleep(1)
    await typew.edit("Pengen gitu-gituan")
    sleep(1)
    await typew.edit("Ayo cepat masukkan")
    sleep(1)
    await typew.edit("Jangan lama - lama")
    sleep(1)
    await typew.edit("Pliss cobain")
    sleep(1)
    await typew.edit("Jangan di nanti - nanti")
    sleep(1)
    await typew.edit("Ayo kita happy")
    sleep (1)
    await typew.edit("Tapi pake pengaman")
    
    
@register(outgoing=True, pattern='^.dahlah(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**`Ayo Menyerah`**")
    sleep(2)
    await typew.edit("**`Ngapain Semangat`**")
                     
    
@register(outgoing=True, pattern='^.repobot(?: |$)(.*)')  
async def typewriter(typew):
    typew.pattern_match.group(1)
    sleep(1)
    await typew.edit("👻")
    sleep(2)
    await typew.edit("**🔥𝙋𝙤𝙘𝙤𝙣𝙜 - 𝙐𝙨𝙚𝙧𝙗𝙤𝙩🔥**\n\n [𝚂𝚎𝚗𝚝𝚞𝚑 𝙰𝚔𝚞 𝙱𝚎𝚋](https://github.com/poocong/Pocong-Userbot)\n 𝐓𝐡𝐚𝐧𝐤𝐬 𝐅𝐨𝐫 𝐔𝐬𝐢𝐧𝐠👻")

   
@register(outgoing=True, pattern='^.ehm(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("Eh..")
    sleep(2)
    await typew.edit("Suara kamu ga jelas")
    sleep(2)
    await typew.edit("Kayanya kalau call pribadi lebih jelas")
    sleep(2)
    await typew.edit("Gamau nyoba?")

    
#P o c o n g - U s e r b o t
#Ini Tercipta Hasil kegabutan ku Doang
#Jadi Ga Usah Bacot Ngentod
    
CMD_HELP.update({
    "animasi1":
    "**Perintah**: **animasi1**\
    \n**Total Command: 11**\
    \n\nㅤㅤ•**Cmd**: .hai\
    \n•**Function**: Cosplay Nissa Sablon\
    \n\nㅤㅤ•**Cmd**: .kntl\
    \n•**Function**: Cek Aja dh\
    \n\nㅤㅤ•**Cmd**: .alay\
    \n•**Function**: Lumayanlah Buat Nyindir\
    \n\nㅤㅤ•**Cmd**: .ange\
    \n•**Function**: Ketik Ini Kalo Lu Lagi Sange\
    \n\nㅤㅤ•**Cmd**: .engas\
    \n•**Function**: Sange berat\
    \n\nㅤㅤ•**Cmd**: .ehm\
    \n•**Function**: Eum Biasalah cewe mau nya call mulu\
    \n\nㅤㅤ•**Cmd**: .lopu\
    \n•**Function**: Nyatakan Cinta Ke Cewe Orng\
    \n\nㅤㅤ•**Cmd**: .hujan\
    \n•**Function**: Penyesalan Seorang Laki-laki Yang Diulangin Terus Menerus\
    \n\nㅤㅤ•**Cmd**: .dahlah\
    \n•**Function**: Cek Aja dh sndri\
    \n\nㅤㅤ•**Cmd**: .jawa\
    \n•**Function**: Jawa Pride Ni Bos.\
    \n\nㅤㅤ•**Cmd**: .erpe\
    \n•**Function**: Buat Nyindir Nak Rp Yg Goblok."
    
    
})
